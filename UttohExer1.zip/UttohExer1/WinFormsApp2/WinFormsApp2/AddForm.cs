﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: April 11, 2021
 * Brief Description of this Class: 
 * 
 * -- This class handles the logic of the add form
 * -- If one of the fields is empty / whitespace only, write error to remarks field
 * -- If there is no problem, create Node and push to the stack array
 *  
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class AddForm : Form
    {
        public AddForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // fetch screen data
            String author = textBox1.Text;
            String title = textBox2.Text;

            // check if there is missing data
            // if there is, output to "Remarks"
            if (author.Trim().Equals("") || title.Trim().Equals(""))
            {
                textBox3.Text = "Incomplete input.";
            }
            else
            {
                // if data input is ok:

                // create Node
                Node newNode = new Node(author, title);

                // push data to the globalstack
                Program.globalStack.push(newNode);

                // send confirmation msg to the rich text box
                Program.theTopForm.getRichTextBox().AppendText(
                    "Added " + title + 
                    " by " + author + "." + 
                    Environment.NewLine);

                // close "add textbook" textbox
                this.Close();
            }
        }
    }
}
