﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: April 11, 2021
 * Brief Description of this Class: 
 * 
 * -- This class handles the logic of the main form
 * -- Add Textbook : Stack's push(new Node) function - writes new node data to the stack
 * -- Read Textbook: Stack's peek() then pop() function - checks the top data in the stack, returns it, then pops it after
 * -- See Textbook Details: Stack's peek() function - checks the top data in the stack and returns it
 * -- Return Textbook to Shelf: similar to Read Textbook function, but for all data
 *      while(!stack.isEmpty()){
 *          stack.peek();
 *          stack.pop()
 *      } 
 * -- Exit: Exit app
 * 
 * Program performance: writes the response data to a textbox.
 *  
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class MainForm : Form
    {

        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // "add textbook" was clicked
            // instantiate new form for writing data to the stack
            AddForm addForm = new AddForm();
            addForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // "read textbook" was clicked
            if (Program.globalStack.isEmpty())
            {
                // if empty, write to the main rich text box
                writeStackEmpty();
            }
            else
            {
                // peek stack
                Node topNode = Program.globalStack.peek();
                Program.theTopForm.richTextBox1.AppendText(
                    "Reading the book with the title " + topNode.getTitle() + 
                    " by " + topNode.getAuthor() + "." + 
                    Environment.NewLine);

                // pop top node
                Program.globalStack.pop();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // "see textbook details" was clicked
            if (Program.globalStack.isEmpty())
            {
                // if empty, write to the main rich text box
                writeStackEmpty();
            }
            else
            {
                // peek top of stack only
                Node topNode = Program.globalStack.peek();

                // write output to the textbox
                Program.theTopForm.richTextBox1.AppendText(
                    "This book is by " + topNode.getAuthor() + "." + 
                    Environment.NewLine);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // "return textbooks to shelf" was clicked
            if (Program.globalStack.isEmpty())
            {
                // if empty, write to the main rich text box
                writeStackEmpty();
            }
            else
            {
                // write the start of the action
                Program.theTopForm.richTextBox1.AppendText(
                    "Current titles:" + 
                    Environment.NewLine);

                // repeatedly peek then pop
                while (!Program.globalStack.isEmpty())
                {
                    // get top node and write it to textbox
                    Node topNode = Program.globalStack.peek();
                    Program.theTopForm.richTextBox1.AppendText(
                        topNode.getTitle() + 
                        Environment.NewLine);
                    // pop top node afterwards
                    Program.globalStack.pop();
                }
                
                // send confirmation msg
                Program.theTopForm.richTextBox1.AppendText(
                    "All stack data popped." + 
                    Environment.NewLine);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // exit app
            Application.Exit();
        }

        // function to traverse the text box scroll to the latest input
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        { 
            // set the current caret position to the end
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            // scroll it automatically
            richTextBox1.ScrollToCaret();
        }

        // helper class to write to text box if there is no data in stack
        private void writeStackEmpty()
        {
            Program.theTopForm.richTextBox1.AppendText(
                "No data exists in stack." + 
                Environment.NewLine);
        }

    }
}
