﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: April 11, 2021
 * Brief Description of this Class: 
 * 
 * -- Stack class handles the actual stack array creation
 * -- Stack Class Variables:
 *      Node[stack] - instantiates the array which will contain the Nodes
 *      int top     - defines the stack pointer (for locating)
 *      int size    - handles the current size/length of the array
 *      
 * -- Node class below serves as the container for the data
 * -- Node Class Variables: 
 *      String author - holds the Node's author data
 *      String title  - holds the Node's title data
 *
 * Creator's Notes:
 * ** I defined Node and Stack in 1 class only since it is quite short...
 * ** But usually, these two should be separate.
 * 
*/

using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp2
{
    // stack class implemented using array
    class Stack
    {
        Node[] stack;
        int top = -1;
        int size = 0;

        // add new item to top of stack
        public void push(Node n)
        {
            // grow the array size by 1
            Array.Resize(ref stack, ++size);

            // increment pointer and put data in
            // array with corresponding index
            stack[++top] = n;
        }

        // peek top item from stack
        public Node peek()
        {
            if (!isEmpty())
            {
                // if the stack has data,
                // return pointer's stack value
                return stack[top];
            }
            return null;
        }

        //  remove top item from stack
        public void pop()
        {
            if (!isEmpty())
            {
                // decrease size of array by 1
                Array.Resize(ref stack, --size);
                // decrease pointer index by 1
                top--;
            }
        }

        // empty checking
        public bool isEmpty()
        {
            return size == 0;
        }
    }

    // class used to define the node that will hold the data
    class Node
    {
        readonly private String author;
        readonly private String title;

        public Node(String tmpAuthor, String tmpTitle)
        {
            this.author = tmpAuthor;
            this.title = tmpTitle;
        }

        public String getTitle()
        {
            return title;
        }

        public String getAuthor()
        {
            return author;
        }
    }
}
