﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: May 2, 2021
 * Brief Description of this Class: 
 * 
 * -- BST class serves as the tree class
 * -- BST Class Variables: 
 *      Npde root - is the root of the tree
 *      StringBuilder sb - handles text when printing the tree
 *      
 * -- Function descriptions are stored in MainForm's comments
 *      
 * Creator's notes:
 * ** I built wrapper functions since most of the solutions for the problems
 * ** were written recursively. I built them to facilitate calls from the UI classes.
*/

using System;
using System.Text;

namespace WinFormsApp3
{
    class BST
    {
        // constructor initialization
        public Node root { get; set; }

        public StringBuilder sb = new StringBuilder(); 

        public BST()
        {
            root = null;
        }

        /* ---------------------------------------------------------- */
        // INSERT
        // wrapper class:
        public void InsertNode(int value)
        {
            root = InsertNodeImpl(root, value);
        }
        
        // implementation (recursive):
        private Node InsertNodeImpl(Node cur, int value) 
        { 
            // if the current node is null, return new node
            if (cur == null)
            {
                return new Node(value);
            }

            // recur in tree
            if (value < cur.key)
            {
                // if value is less than current node
                // recur in left side of tree
                cur.left = InsertNodeImpl(cur.left, value);
            }
            else if (value > cur.key)
            {
                // if value is greater than current node
                // recur in right side of tree
                cur.right = InsertNodeImpl(cur.right, value);
            }
            // return pointer
            return cur;
        }

        /* ---------------------------------------------------------- */
        // DELETE
        // wrapper class:
        public void DeleteNode(int value)
        {
            root = DeleteNodeImpl(root, value);
        }
        
        // implementation (recursive):
        private Node DeleteNodeImpl(Node cur, int value) 
        {
            // if the tree is empty,
            // return nothing
            if (cur == null)
            {
                return cur;
            }

            // recur down in tree
            if (value < cur.key)
            {
                // if value is less than current node,
                // check in left side of tree
                cur.left = DeleteNodeImpl(cur.left, value);
            }
            else if (value > cur.key)
            {
                // if value is greater than current node,
                // check in right side of tree
                cur.right = DeleteNodeImpl(cur.right, value);
            }
            else
            {
                // if the node has 
                // no child or one child
                if (cur.left == null)
                {
                    return cur.right;
                } 
                else if (cur.right == null)
                {
                    return cur.left;
                }

                // if the node has two children
                // get successor which is the smallest value
                // in the right subtree of the current node
                cur.key = GetMin(cur.right);
                // then delete the successor
                cur.right = DeleteNodeImpl(cur.right, cur.key);
            }
            // return node pointer
            return cur;
        }

        /* ---------------------------------------------------------- */
        // MINIMUM
        // returns integer value:
        public int GetMin(Node cur)
        {
            // traverse leftmost side
            // while there are nodes to traverse
            while (cur.left != null)
            {
                cur = cur.left;
            }
            return cur.key;
        }

        // returns node:
        private Node GetMinNode(Node cur)
        {
            // traverse leftmost side
            // while there are nodes to traverse
            while (cur.left != null)
            {
                cur = cur.left;
            }
            return cur;
        }

        /* ---------------------------------------------------------- */
        // MAXIMUM
        // returns integer value:
        public int GetMax(Node cur)
        {
            // traverse rightmost side
            // while there are nodes to traverse
            while (cur.right != null)
            {
                cur = cur.right;
            }
            return cur.key;
        }

        private Node GetMaxNode(Node cur)
        {
            // traverse rightmost side
            // while there are nodes to traverse
            while (cur.right != null)
            {
                cur = cur.right;
            }
            return cur;
        }

        /* ---------------------------------------------------------- */
        // SUCCESSOR
        public Node GetSuccessor(Node root, Node cur)
        {
            // if the right subtree of the current node is not null
            // go to right subtree and return node with min value
            if (cur.right != null)
            {
                return GetMinNode(cur.right);
            }

            Node successor = null;

            // if the right subtree of the current node 
            // is null, traverse tree from root:
            // if cur data > root key : right side traversal
            // else, left side traversal
            while (root != null)
            {
                if (cur.key < root.key)
                {
                    successor = root;
                    root = root.left;
                }
                else if (cur.key > root.key)
                {
                    root = root.right;
                }
                else
                {
                    break;
                }
            }
            return successor;
        }

        /* ---------------------------------------------------------- */
        // PREDECESSOR
        public Node GetPredecessor(Node root, Node cur)
        {
            // if the left subtree of the current node is not null
            // go to left subtree and return node with max value
            if (cur.left != null)
            {
                return GetMaxNode(cur.left);
            }

            Node predecessor = null;

            // if the right subtree of the current node 
            // is null, traverse tree from root:
            // if cur data < root key : left side traversal
            // else, right side traversal
            while (root != null)
            {
                if (cur.key > root.key)
                {
                    predecessor = root;
                    root = root.right;
                }
                else if (cur.key < root.key)
                {
                    root = root.left;
                }
                else
                {
                    break;
                }
            }
            return predecessor;
        }

        /* ---------------------------------------------------------- */
        // SEARCH
        public Node SearchNode(Node cur, int value)
        {
            // if root is null or current node's key
            // is equal to the current search value
            if (cur == null || cur.key == value)
            {
                return cur;
            }

            if (cur.key < value)
            {
                // if value is greater than 
                // current node's key
                return SearchNode(cur.right, value);
            }
            else
            {
                // if value is less than 
                // current node's key
                // * did not put "=" in ">=" (else case) since it 
                // * will be caught in the first checking
                return SearchNode(cur.left, value);
            }
        }

        /* ---------------------------------------------------------- */
        // ASCENDING PRINT
        // wrapper class:
        public StringBuilder GetAscendingOutput()
        {
            sb.Clear();
            GetAscendingOutputImpl(root);
            return sb;
        } 

        // implementation (recursive):
        public void GetAscendingOutputImpl(Node cur)
        {
            // if the current node is null
            if (cur == null)
            {
                return;
            }

            // print left side first
            GetAscendingOutputImpl(cur.left);
            // print parent node
            if (cur != null)
            {
                sb.Append(cur.key + ", ");
            }
            // print right side after
            GetAscendingOutputImpl(cur.right);
        }

        /* ---------------------------------------------------------- */
        // PRINT TREE
        public StringBuilder OutputTreelike()
        {
            sb.Clear();
            OutputTreelikeImpl(root, "");
            return sb;
        }

        public void OutputTreelikeImpl(Node cur, String prefix)
        {
            // if the current node is null
            if (cur == null)
            {
                return;
            }
            // print current node
            sb.Append(prefix + "- " + cur.key + "\r\n");
            // print current node's left side
            OutputTreelikeImpl(cur.left, prefix + "(L)");
            // print current node's right side
            OutputTreelikeImpl(cur.right, prefix + "(R)");
        }

        /* ---------------------------------------------------------- */
        // RESET TREE
        public void ResetTree()
        {
            // set the tree's root to null
            // to basically delete it
            root = null;
        }
    }
}
