﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: May 2, 2021
 * Brief Description of this Class: 
 * 
 * -- This class handles the logic of the main form
 * -- Add Node - BST's add node function. Inserts data in the BST depending on value.
 *               Put in left side when less than current node, right when greater than.
 * -- Delete Node - BST's delete node function. Deletes node if it exists:
 *      Delete logic:
 *          When there is no child / one child: splice the node and set parent's pointer to point to 
 *                                              null (no child) or the spliced node's child.
 *          When there are two children: use the successor as the replacement of the spliced node.
 * -- Minimum - Gets BST's minimum value.
 * -- Maximum - Gets BST's maximum value.
 * -- Successor - Based on the input, retrieves the input's successor (next node in asc order).
 * -- Predecessor - Based on the input, retrieves the input's predecessor (prev node in asc order).
 * -- Search - Searches if the input value exists in the current BST.
 * -- Asc Print - Prints the BST in an ascending order.
 * -- Print Tree - Prints the tree in a tree-like fashion:
 *      * Appends (L) / (R) based on the location of the nodes, and how deep it is in the tree.
 * -- Reset Tree - Resets the tree (delete all).
 * -- Clear Screen - Clears the richtextbox if there is data on screen.
 * -- Clear Input - Clears the text box where values are inputted.
 * -- Exit - terminates the application.
 * 
 * -- Added helper functions:
 * -- inputCheck - for input validation
 * -- rtb1_textChanged - for richtextbox carat setting
 * -- rtbPrint - for richtextbox printing
 * -- isBSTEmpty - checks if BST is empty
 * -- currentTreePrint - prints current tree
 * 
 * Creator's notes:
 * ** I did not allow same input handling to make it simple.
 * 
 * Program performance: writes the response data to a textbox.
 *  
*/

using System;
using System.Text;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        // helper function: input checking
        private int inputCheck(String stringToTest, bool shouldNotExist)
        {
            bool number = int.TryParse(stringToTest, out int n);
            if (String.IsNullOrEmpty(stringToTest))
            {
                // empty check
                String confMsg = "Please provide input.";
                rtbPrint(confMsg);
                return -1;
            }
            if (!number)
            {
                // not a number check
                String confMsg = "Input is not a number.";
                rtbPrint(confMsg);
                return -1;
            }
            if (n < 0)
            {
                // negative input check
                String confMsg = "Negative input is not allowed.";
                rtbPrint(confMsg);
                return -1;
            }
            if (Program.globalBST.SearchNode(Program.globalBST.root, n) != null && shouldNotExist)
            {
                // existence check for new data
                String confMsg = n + " already exists. Input is not allowed. ";
                rtbPrint(confMsg);
                return -1;
            }
            else if (Program.globalBST.SearchNode(Program.globalBST.root, n) == null && !shouldNotExist)
            {
                // existence check for existing data
                String confMsg = n + " does not exist in the BST. ";
                rtbPrint(confMsg);
                return -1;
            }
            return n;
        }

        // helper function: traverse the text box scroll to the latest input
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            // set the current caret position to the end
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            // scroll it automatically
            richTextBox1.ScrollToCaret();
        }

        // helper function: printing to rich text box
        private void rtbPrint(String text)
        {
            Program.theTopForm.getRichTextBox().AppendText(text + Environment.NewLine);
        }

        // helper function: bst empty check
        private bool isBSTEmpty()
        {
            if (Program.globalBST.root == null)
            {
                String confMsg = "BST is empty.";
                rtbPrint(confMsg);
                return true;
            }
            return false;
        }

        // helper function: tree printing
        private void currentTreePrint() 
        {
            String tree = Program.globalBST.OutputTreelike().ToString();
            String outStr = "Current Tree: \r\n" + tree;
            Program.theTopForm.getRichTextBox().AppendText(outStr);
        }

        // add node
        private void button1_Click(object sender, EventArgs e)
        {
            String numberToTest = textBox1.Text;
            // input checking
            int num = inputCheck(numberToTest, true);
            if (num == -1)
            {
                return;
            }
            else
            {
                // add node
                Program.globalBST.InsertNode(num);
                // confirmation msg
                String confMsg = "Added " + num + " to BST.";
                rtbPrint(confMsg);
                currentTreePrint();
            }
        }
        
        // delete node
        private void button2_Click(object sender, EventArgs e)
        {
            String numberToTest = textBox1.Text;
            // input checking
            int num = inputCheck(numberToTest, false);
            if (num == -1)
            {
                return;
            }
            else
            {
                // delete node
                Program.globalBST.DeleteNode(num);
                // confirmation msg
                String confMsg = "Deleted " + num + " from BST.";
                rtbPrint(confMsg);
                if (!isBSTEmpty())
                {
                    // if not empty, reprint tree
                    currentTreePrint();
                }
            }
        }

        // get minimum
        private void button3_Click(object sender, EventArgs e)
        {
            // check if BST has values
            if (!isBSTEmpty())
            {
                // min value
                int min = Program.globalBST.GetMin(Program.globalBST.root);
                // confirmation msg
                String confMsg = "The BST's minimum value is " + min + ".";
                rtbPrint(confMsg);
            }
        }
        
        // get maximum
        private void button4_Click(object sender, EventArgs e)
        {
            // check if BST has values
            if (!isBSTEmpty())
            {
                // max value
                int max = Program.globalBST.GetMax(Program.globalBST.root);
                // confirmation msg
                String confMsg = "The BST's maximum value is " + max + ".";
                rtbPrint(confMsg);
            }
        }

        // get successor
        private void button5_Click(object sender, EventArgs e)
        {
            String numberToTest = textBox1.Text;
            // input checking
            int num = inputCheck(numberToTest, false);
            if (num == -1)
            {
                return;
            }
            else
            {
                // find node
                Node cur = Program.globalBST.SearchNode(Program.globalBST.root, num);
                // get successor
                Node succ = Program.globalBST.GetSuccessor(Program.globalBST.root, cur);
                if (succ != null)
                {
                    // confirmation msg if there is a successor
                    String confMsg = num + "'s successor in the current BST is " + succ.key + ".";
                    rtbPrint(confMsg);
                }
                else
                {
                    // confirmation msg if there is no successor (max value already)
                    String confMsg = "There is no successor for " + num + ".";
                    rtbPrint(confMsg);
                }
            }
        }

        // get predecessor
        private void button6_Click(object sender, EventArgs e)
        {
            String numberToTest = textBox1.Text;
            // input checking
            int num = inputCheck(numberToTest, false);
            if (num == -1)
            {
                return;
            }
            else
            {
                // find node
                Node cur = Program.globalBST.SearchNode(Program.globalBST.root, num);
                // get predecessor
                Node prec = Program.globalBST.GetPredecessor(Program.globalBST.root, cur);
                if (prec != null)
                {
                    // confirmation msg if there is a predecessor
                    String confMsg = num + "'s predecessor in the current BST is " + prec.key + ".";
                    rtbPrint(confMsg);
                }
                else
                {
                    // confirmation msg if there is no successor (min value already)
                    String confMsg = "There is no predecessor for " + num + ".";
                    rtbPrint(confMsg);
                }
            }
        }

        // search
        private void button7_Click(object sender, EventArgs e)
        {
            String numberToTest = textBox1.Text;
            // input checking
            int num = inputCheck(numberToTest, false);
            if (num == -1)
            {
                return;
            }
            else
            {
                // find node
                Node cur = Program.globalBST.SearchNode(Program.globalBST.root, num);
                if (cur == null)
                {
                    // node not found
                    // confirmation msg
                    String confMsg = num + " was not found in the BST.";
                    rtbPrint(confMsg);
                }
                else
                {
                    // node found
                    // confirmation msg
                    String confMsg = num + " was found in the BST.";
                    rtbPrint(confMsg);
                }
            }
        }

        // ascending print
        private void button8_Click(object sender, EventArgs e)
        {
            if (!isBSTEmpty())
            {
                // ascending print fetch
                StringBuilder sb = Program.globalBST.GetAscendingOutput();
                string strSb = sb.ToString();
                // confirmation msg
                String confMsg = "The BST printed in ascending order: " + strSb.Substring(0, strSb.Length - 2) + ".";
                rtbPrint(confMsg);
            }
        }

        // clear screen
        private void button9_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        // exit app
        private void button10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // reset tree
        private void button11_Click(object sender, EventArgs e)
        {
            // reset tree
            Program.globalBST.ResetTree();
            // confirmation msg
            String confMsg = "The BST was reset.";
            rtbPrint(confMsg);
        }

        // clear input
        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        // print existing tree
        private void button13_Click(object sender, EventArgs e)
        {
            if (!isBSTEmpty())
            {
                currentTreePrint();
            }
        }
    }
}
