﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: May 2, 2021
 * Brief Description of this Class: 
 * 
 * -- Node class serves as the container for the data
 * -- Node Class Variables: 
 *      int key - holds the Node's value
 *      Node left - is the Node's left pointer
 *      Node right - is the Node's right pointer
 *      
 * Creator's notes:
 * ** I did not build a parent pointer since the Exercise can be solved using
 * ** the left and right pointer. For the successor / predecessor functions,
 * ** if data cannot be found by traversal, I check from the ancestor.
 * 
*/

using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp3
{
    class Node
    {
        public int key { get; set; }
        public Node left { get; set; }
        public Node right { get; set; }
        public Node(int value) 
        {
            key = value;
            left = null;
            right = null;
        }
    }
}
