/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: May 2, 2021
 * Brief Description of this Class: 
 * 
 * -- This class instantiates the Main Form of the program
 * -- Aside from this, it also defines global variables:
 *    BST globalBST       - instantiates a new tree when opening the program
 *    MainForm theTopForm - handles the top form
 * 
*/

using System;
using System.Windows.Forms;

namespace WinFormsApp3
{
    static class Program
    {
        // global access variable for top form
        public static MainForm theTopForm;

        // global stack definition (for all forms)
        public static BST globalBST = new BST();

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            theTopForm = new MainForm();
            Application.Run(theTopForm);
        }
    }
}
