﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: May 18, 2021
 * Brief Description of this Class: 
 * 
 * -- Graph class serves as the Graph template
 * -- Pertinent Graph Class Variables: 
 *      Node[] graphNData - holds the vertices of the graph
 *      bool[,] graphNMatrix - holds the edge information of the graph
 *      StringBuilder sb - handles text when printing the tree
 *      
 * -- Function descriptions are stored in MainForm's comments
 *      
*/

using System;
using System.Text;

namespace WinFormsApp4
{
    class Graph
    {
        Node[] graphNData;
        bool[,] graphNMatrix;
        public StringBuilder sb = new StringBuilder();

        // comma delimiter for formatting
        public readonly String delimiter = ", ";

        // constructor
        public Graph(Node[] tmpGraphNData, bool[,] tmpgraphNMatrix)
        {

            graphNData = tmpGraphNData;
            graphNMatrix = tmpgraphNMatrix;
        }

        // -------------------------------------------------------------------
        // depth first search/traversal
        // stack implementation
        // return true if search term is found whilst traversing
        // return false if not found while traversing
        public bool Dfs(Node node, String srhTerm = "")
        {
            // reset the vertices' isVisited flag
            ResetGraphData();
            // clear the output string
            sb.Clear();
            // instantiate a new stack
            Stack stack = new Stack();
            // push the current node as the first in the stack
            stack.Push(node);
            if (!srhTerm.Trim().Equals(null) && srhTerm.Equals(node.data))
            {
                // if the first node pushed is equal 
                // to the search term node, return true
                return true;
            }
            while (!stack.IsEmpty())
            {
                // remove the top of the stack for examination
                Node el = stack.Peek();
                stack.Pop();
                if (!el.isVisited)
                {
                    // if the top of the stack is unvisited
                    // mark as visited and add to the output
                    sb.Append(el.data + delimiter);
                    el.isVisited = true;
                }

                // try to find the neighbor using adjacency matrix
                Node[] neighbors = FindNeighbors(el);
                for (int i = 0; i < neighbors.Length; i++)
                {
                    Node n = neighbors[i];
                    if (n != null && !n.isVisited)
                    {
                        // if the node's neighbor is unvisited
                        if (!srhTerm.Trim().Equals(null) && srhTerm.Equals(n.data))
                        {
                            // if the neighbor matches the search term, return true
                            return true;
                        }
                        // add the node's neighbor to the stack
                        stack.Push(n);
                    }
                }
            }
            // remove trailing data
            FormatOutput();
            return false;
        }

        // recursive interface for external call
        public void DfsRecursive(Node curNode)
        {
            // reset the vertices' isVisited flag
            ResetGraphData();
            // clear the output string
            sb.Clear();
            // start the recursive implementation
            DfsRecursiveImpl(curNode);
            // remove trailing data
            FormatOutput();
        }

        // recursive implementation
        // implementation can be thought of as stack-like
        private void DfsRecursiveImpl(Node curNode)
        {
            // append current node to the output string
            sb.Append(curNode.data + delimiter);
            // try and find the neighbors of the node
            // using the adjacency matrix of the graph
            Node[] neighbors = FindNeighbors(curNode);
            // set current node as visited
            curNode.isVisited = true;
            for (int i = 0; i < neighbors.Length; i++)
            {
                Node n = neighbors[i];
                if (n != null && !n.isVisited)
                {
                    // for every neighbor, recurse
                    DfsRecursiveImpl (n);
                }
            }

        }

        // -------------------------------------------------------------------
        // breadth first search/traversal
        // queue implementation
        // return true if search term is found whilst traversing
        // return false if not found while traversing
        public bool Bfs(Node node, String srhTerm = "")
        {
            // reset the vertices' isVisited flag
            ResetGraphData();
            // clear the output string
            sb.Clear();
            // instantiate a new queue
            Queue queue = new Queue();
            // enqueue node to queue as first item
            queue.Enqueue(node);
            if (!srhTerm.Trim().Equals(null) && srhTerm.Equals(node.data))
            {
                // if the first node pushed is equal 
                // to the search term node, return true
                return true;
            }
            // set the first node's isVisited flag to true
            node.isVisited = true;
            while (!queue.IsEmpty())
            {
                // remove the top of the stack for examination
                Node el = queue.Peek();
                queue.Dequeue();
                // add to the output
                sb.Append(el.data + ", ");
                // find the current node's neighbors
                Node[] neighborNodes = FindNeighbors(el);
                for (int i = 0; i < neighborNodes.Length; i++)
                {
                    Node n = neighborNodes[i];
                    if (n != null && !n.isVisited)
                    {
                        // if the neighbor node is unvisited
                        if (!srhTerm.Trim().Equals(null) && srhTerm.Equals(n.data))
                        {
                            // if the neighbor matches the search term, return true
                            return true;
                        }
                        // add the neighbor node to the queue
                        queue.Enqueue(n);
                        // mark neighbor node as visited
                        n.isVisited = true;
                    }
                }
            }
            // remove trailing data
            FormatOutput();
            return false;
        }

        // -------------------------------------------------------------------
        // utility function for neighbor
        // search and edge checking
        public Node[] FindNeighbors(Node curNode)
        {
            int nodeIndex = -1;
            Node[] neighbors = new Node[] { };

            // try to find the node index
            for (int i = 0; i < graphNData.Length; i++)
            {
                // check if current node
                // exists in the graph
                if (graphNData[i].Equals(curNode))
                {
                    // if match, then break loop
                    nodeIndex = i;
                    break;
                }
            }

            if (nodeIndex != -1)
            {
                // if the node index is found,
                // iterate through the adjacencyRow
                // inside the adjacencyMatrix and
                // check for connection (if true in adjacencyMatrix)
                for (int j = 0; j < graphNData.Length; j++)
                {
                    if (graphNMatrix[nodeIndex, j])
                    {
                        // if connected, it is recognized as neighbors
                        // get current length as the pointer index
                        int ptrIdx = neighbors.Length;
                        // grow the array size by 1
                        Array.Resize(ref neighbors, neighbors.Length + 1);
                        // then, add the data on the correct index
                        neighbors[ptrIdx] = graphNData[j];
                    }
                }
            }
            // return current node's neighbors
            return neighbors;
        }

        // -------------------------------------------------------------------
        // helper methods
        // graph reset
        public void ResetGraphData()
        {
            // for all items in graph's vertex,
            // set isVisited flag to false
            for (int i=0; i<graphNData.Length; i++)
            {
                graphNData[i].isVisited = false;
            }
        }

        // format the output
        private void FormatOutput()
        {
            // remove last delimiter
            sb.Length -= 2;
            // add period
            sb.Append(".");
        }

    }
}
