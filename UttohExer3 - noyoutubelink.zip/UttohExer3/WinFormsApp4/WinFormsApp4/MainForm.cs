﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: May 2, 2021
 * Brief Description of this Class: 
 * 
 * -- This class handles the logic of the main form.
 * -- This class also has the graph definition (vertices & adjacency matrix) for Graph 1 and 2.
 * -- Depth First Traversal / Search: starts traversal from root node then walks as far as possible in one 
 *                                  direction before backtracking and exploring another path.
 * --   Traversal - returns the traversal path.
 * --       Implemented in 2 methods:
 * --           Stack - most common way to implement.
 * --               Algorithm:
 *                      1. pick the starting node A and push to stack.
 *                      2. push all adjacent nodes or neighbors of A into a stack. this is determined by the adjacency matrix.
 *                      3. mark A as visited.
 *                      4. peek and pop node from stack to check next node B.
 *                      5. get the neighbors of the next node B and push to stack.
 *                      6. repeat 2-6 until stack is empty, replacing A instance with B every loop.
 * --           Recursion - recursion can be done since recursion itself is stack-like.
 * --   Search - searches the stack using the iterations done, to sift one by one.
 * --       * implemented using the stack implementation because it may be difficult to get the match via recursion.
 * -- Breadth First Traversal / Search: starts traversal in a layer by layer fashion before moving to the next set of nodes.
 * --   Traversal - returns the traversal path. Is implemented using a queue.
 * --               Algorithm:
 *                      1. pick starting node A and enqueue. set node as visited.
 *                      2. dequeue the head of the queue.
 *                      3. find the head's adjacent nodes or neighbors using the adjacency matrix.
 *                      4. if a neighbor is unvisited, add to queue and mark as visited.
 *                      5. mark neighbor node as visited.
 *                      6. repeat 2-6 until queue is empty.
 * --   Search - searches the queue using the iterations done, to sift one by one.
 * -- Clear Screen - Clears the richtextbox if there is data on screen.
 * -- Clear - Clears the text box where values are inputted.
 * -- Exit - terminates the application.
 * 
 * -- Added helper functions:
 * -- inputCheck - for input validation
 * -- rtb1_textChanged - for richtextbox carat setting
 * -- rtbPrint - for richtextbox printing
 * -- radioButtonCheckChanged1/radioButtonCheckChanged2 - enables/disables appropriate groupbox (groupbox contains the radiobuttons).
 * -- getSelectedRadio - retrieves the current selected radio buttons. 
 * 
 * Creator's notes:
 * ** I did not allow same input handling to make it simple.
 * ** Also, the program does not require the use of a global instance of a graph, so I create instances per call.
 * ** DFS may have different outputs depending on stack and recursion.
 * 
 * Program performance: writes the response data to a textbox.
 *  
*/

using System;
using System.Linq;
using System.Windows.Forms;

namespace WinFormsApp4
{
    public partial class MainForm : Form
    {

        // ---------------------------------------------------------------------------------------------
        // graph 1 representation
        // vertex data:
        private readonly Node[] graphOneVertex = new Node[7] {
                new Node("A"),
                new Node("B"),
                new Node("C"),
                new Node("D"),
                new Node("E"),
                new Node("F"),
                new Node("G")
        };
        // edge reference:
        private readonly bool[,] graphOneEdges = new bool[7, 7]
        {    
                // adjacency matrix of graph 1
                //   A      B      C      D      E      F      G
                { false,  true, false, false, false, false, false }, // A (A -> B)
                { false, false,  true, false,  true, false, false }, // B (B -> C), (B -> E)
                {  true, false, false,  true, false, false,  true }, // C (C -> A), (C -> D), (C -> G)
                {  true, false, false, false, false, false, false }, // D (D -> A)
                { false, false,  true, false, false,  true, false }, // E (E -> C), (E -> F)
                { false, false, false, false, false, false,  true }, // F (F -> G)
                { false, false, false,  true, false, false, false }  // G (G -> D)
        };
        // ---------------------------------------------------------------------------------------------
        // graph 2 representation
        // vertex data:
        private readonly Node[] graphTwoVertex = new Node[6] {
                new Node("0"),
                new Node("1"),
                new Node("2"),
                new Node("3"),
                new Node("4"),
                new Node("5")
        };
        // edge reference:
        private readonly bool[,] graphTwoEdges = new bool[6, 6]
        {
                // adjacency matrix of graph 2
                //   0     1      2      3      4      5
                { false,  true, false, false, false, false }, // 0 (0 -> 1)
                { false, false,  true, false, false,  true }, // 1 (1 -> 2), (1 -> 5)
                { false, false, false,  true,  true, false }, // 2 (2 -> 3), (2 -> 4)
                { false, false, false, false, false, false }, // 3
                { false, false, false, false, false,  true }, // 4 (4 -> 5)
                { false, false, false, false, false, false }  // 5
        };
        // ---------------------------------------------------------------------------------------------

        // radio button selection
        private bool isGraph1Selected;
        private int graph1StartPointSelected;
        private int graph2StartPointSelected;

        // traversal messages
        private readonly string graph1TraversePrefix = "Graph 1";
        private readonly string graph2TraversePrefix = "Graph 2";
        private readonly string dftMsg1 = " DFT via Stack: ";
        private readonly string dftMsg2 = " DFT via Recursion: ";
        private readonly string bftMsg1 = " BFT via Queue: ";

        // search messages
        private readonly string invalidInputMsg = "Invalid input. Please try again.";
        private readonly string graph1SrhPrefix = "Graph 1, searched ";
        private readonly string graph2SrhPrefix = "Graph 2, searched ";
        private readonly string dfsMsgFound = " via DFS: Found.";
        private readonly string dfsMsgNotFound = " via DFS: Not Found.";
        private readonly string bfsMsgFound = " via BFS: Found.";
        private readonly string bfsMsgNotFound = " via BFS: Not Found.";

        public MainForm()
        {
            InitializeComponent();
        }

        // enable graph 1 start point selection
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            // enable selection of Graph 1 start point
            this.groupBox2.Enabled = true;
            // disable selection of Graph 2 start point
            this.groupBox3.Enabled = false;
            // reset Graph 2 start point selection
            this.radioButton11.Checked = true;
        }

        // helper function: enable graph 2 start point selection
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            // disable selection of Graph 1 start point
            this.groupBox2.Enabled = false;
            // enable selection of Graph 2 start point
            this.groupBox3.Enabled = true;
            // reset Graph 1 start point selection
            this.radioButton4.Checked = true;
        }

        // helper function: get selected radio buttons from form
        private void getSelectedRadio()
        {
            // check which type of graph is selected
            isGraph1Selected = (bool) this.groupBox1.Controls.OfType<RadioButton>().
                                            FirstOrDefault(r => r.Checked).Tag;
            // check which start point in graph 1 is selected
            graph1StartPointSelected = (int) this.groupBox2.Controls.OfType<RadioButton>().
                                            FirstOrDefault(r => r.Checked).Tag;
            // check which start point in graph 2 is selected
            graph2StartPointSelected = (int )this.groupBox3.Controls.OfType<RadioButton>().
                                            FirstOrDefault(r => r.Checked).Tag;
        }

        // helper function: traverse the text box scroll to the latest input
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            // set the current caret position to the end
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            // scroll it automatically
            richTextBox1.ScrollToCaret();
        }

        // helper function: printing to rich text box
        private void rtbPrint(String text)
        {
            Program.theTopForm.getRichTextBox().AppendText(text + Environment.NewLine);
        }

        // helper function: input check
        private bool inputCheck(String stringToTest)
        {
            // check if blank or more than one character
            if (String.IsNullOrEmpty(stringToTest.Trim()) | stringToTest.Trim().Length > 1)
            {
                // empty check
                rtbPrint(invalidInputMsg);
                return false;
            }
            return true;
        }

        // depth first traversal function
        // implementation is via stack & recursion
        private void button1_Click(object sender, EventArgs e)
        {
            // get selected radio buttons
            getSelectedRadio();
            // define general graph
            Graph graphNDfs;
            if (isGraph1Selected)
            {
                // do graph one dfs
                graphNDfs = new Graph(graphOneVertex, graphOneEdges);
                // use the start point defined by user
                graphNDfs.Dfs(graphOneVertex[graph1StartPointSelected]);
                // output the data
                rtbPrint(graph1TraversePrefix + dftMsg1 + graphNDfs.sb.ToString());
                // do graph one dfs recursive impl
                graphNDfs.DfsRecursive(graphOneVertex[graph1StartPointSelected]);
                // output the data
                rtbPrint(graph1TraversePrefix + dftMsg2 + graphNDfs.sb.ToString());
            }
            else
            {
                // do graph two dfs
                graphNDfs = new Graph(graphTwoVertex, graphTwoEdges);
                // use the start point defined by user
                graphNDfs.Dfs(graphTwoVertex[graph2StartPointSelected]);
                // output the data
                rtbPrint(graph2TraversePrefix + dftMsg1 + graphNDfs.sb.ToString());
                // do graph two dfs recursive impl
                graphNDfs.DfsRecursive(graphTwoVertex[graph2StartPointSelected]);
                // output the data
                rtbPrint(graph2TraversePrefix + dftMsg2 + graphNDfs.sb.ToString());
            }
        }

        // breadth first traversal function
        private void button2_Click(object sender, EventArgs e)
        {
            // get selected radio buttons
            getSelectedRadio();
            // define general graph
            Graph graphNBfs;
            if (isGraph1Selected)
            {
                // do graph one bfs
                graphNBfs = new Graph(graphOneVertex, graphOneEdges);
                // use the start point defined by user
                graphNBfs.Bfs(graphOneVertex[graph1StartPointSelected]);
                // output the data
                rtbPrint(graph1TraversePrefix + bftMsg1 + graphNBfs.sb.ToString());
            }
            else
            {
                // do graph two bfs
                graphNBfs = new Graph(graphTwoVertex, graphTwoEdges);
                // use the start point defined by user
                graphNBfs.Bfs(graphTwoVertex[graph2StartPointSelected]);
                // output the data
                rtbPrint(graph2TraversePrefix + bftMsg1 + graphNBfs.sb.ToString());
            }
        }

        // depth first search
        private void button3_Click(object sender, EventArgs e)
        {
            // get selected radio buttons
            getSelectedRadio();
            // get text from screen
            string textInput = this.textBox1.Text;
            // define general graph
            Graph graphNDfs;
            if (inputCheck(textInput))
            {
                // input ok
                if (isGraph1Selected) 
                {
                    // graph 1 dfs processing
                    graphNDfs = new Graph(graphOneVertex, graphOneEdges);
                    // use the text input from the user as the search term
                    if (graphNDfs.Dfs(graphOneVertex[0], textInput))
                    {
                        // found
                        rtbPrint(graph1SrhPrefix + textInput + dfsMsgFound);
                    }
                    else
                    {
                        // not found
                        rtbPrint(graph1SrhPrefix + textInput + dfsMsgNotFound);
                    }
                }
                else
                {
                    // graph 2 dfs processing
                    graphNDfs = new Graph(graphTwoVertex, graphTwoEdges);
                    // use the text input from the user as the search term
                    if (graphNDfs.Dfs(graphTwoVertex[0], textInput))
                    {
                        // found
                        rtbPrint(graph2SrhPrefix + textInput + dfsMsgFound);
                    }
                    else
                    {
                        // not found
                        rtbPrint(graph2SrhPrefix + textInput + dfsMsgNotFound);
                    }
                }
            }
        }

        // breadth first search
        private void button4_Click(object sender, EventArgs e)
        {
            // get selected radio buttons
            getSelectedRadio();
            // get text from screen
            string textInput = this.textBox1.Text;
            // define general graph
            Graph graphNBfs;
            if (inputCheck(textInput))
            {
                // input ok
                if (isGraph1Selected)
                {
                    // graph 1 bfs processing
                    graphNBfs = new Graph(graphOneVertex, graphOneEdges);
                    // use the text input from the user as the search term
                    if (graphNBfs.Bfs(graphOneVertex[0], textInput))
                    {
                        // found
                        rtbPrint(graph1SrhPrefix + textInput + bfsMsgFound);
                    }
                    else
                    {
                        // not found
                        rtbPrint(graph1SrhPrefix + textInput + bfsMsgNotFound);
                    }
                }
                else
                {
                    // graph 2 bfs processing
                    graphNBfs = new Graph(graphTwoVertex, graphTwoEdges);
                    // use the text input from the user as the search term
                    if (graphNBfs.Bfs(graphTwoVertex[0], textInput))
                    {
                        // found
                        rtbPrint(graph2SrhPrefix + textInput + bfsMsgFound);
                    }
                    else
                    {
                        // not found
                        rtbPrint(graph2SrhPrefix + textInput + bfsMsgNotFound);
                    }
                }
            }
        }

        // clear search textbox
        private void button7_Click(object sender, EventArgs e)
        {
            this.textBox1.Clear();
        }

        // clear screen
        private void button6_Click(object sender, EventArgs e)
        {
            this.richTextBox1.Clear();
        }

        // exit app
        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
