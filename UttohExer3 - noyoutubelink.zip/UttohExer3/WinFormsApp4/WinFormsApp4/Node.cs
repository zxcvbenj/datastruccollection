﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: May 18, 2021
 * Brief Description of this Class: 
 * 
 * -- Node class serves as the container for the data.
 * -- Node Class Variables: 
 *      string data - holds the vertex data.
 *      bool isVisited - holds the data whether the node was visited already or not.
 *      
 * Creator's Notes:
 * ** On instantiation, isVisited is set to false by default.
 *      
*/

namespace WinFormsApp4
{
    class Node
    {
        public string data { get; set; }
        public bool isVisited { get; set; }
        public Node(string key)
        {
            data = key;
            isVisited = false;
        }
    }
}
