/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: May 18, 2021
 * Brief Description of this Class: 
 * 
 * -- This class instantiates the Main Form of the program
 * -- Aside from this, it also defines global variables:
 *    MainForm theTopForm - handles the top form
 * 
*/

using System;
using System.Windows.Forms;

namespace WinFormsApp4
{
    static class Program
    {
        // global access variable for top form
        public static MainForm theTopForm;
     
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            theTopForm = new MainForm();
            Application.Run(theTopForm);
        }
    }
}
