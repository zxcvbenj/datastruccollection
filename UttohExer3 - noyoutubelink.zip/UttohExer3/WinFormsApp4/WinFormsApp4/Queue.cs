﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: May 18, 2021
 * Brief Description of this Class: 
 * 
 * -- Queue class implementation using arrays.
 * -- Queue Class Variables: 
 *      Node[] queue - holds the Node array; represents the queue itself.
 *      int size - holds the current size of the stack.
 *      int head - is the pointer of the head of the queue.
 *      int tail - is the pointer of the tail of the queue.
 * -- Queue Class Methods:
 *      void Enqueue(Node n) - pushes new node on the rightmost of the array / queue.
 *      Node Peek() - returns the leftmost item in the array / queue.
 *      void Pop() - removes the leftmost item in the array / queue.
 *      bool isEmpty() - queue size checking.
 *      
*/

using System;

namespace WinFormsApp4
{
    class Queue
    {
        Node[] queue;
        int size = 0;
        int head = 0;
        int tail = 0;

        // add item to tail of queue
        public void Enqueue(Node n)
        {
            // grow the array size by 1
            Array.Resize(ref queue, ++size);

            // increment pointer and put data in
            // array with corresponding index
            queue[tail++] = n;
        }

        // peek top item from queue
        public Node Peek()
        {
            if (!IsEmpty())
            {
                // if the queue has data,
                // return head value
                return queue[head];
            }
            return null;
        }

        // remove item from head of queue
        public void Dequeue()
        {
            if (!IsEmpty())
            {
                // shift items to the left by 1
                for (int i = 0; i < tail-1; i++)
                {
                    queue[i] = queue[i + 1];
                }
                // decrease size of array by 1
                Array.Resize(ref queue, --size);
                // decrease tail index by 1
                tail--;
            }
        }

        // empty checking
        public bool IsEmpty()
        {
            return size == 0;
        }
    }
}
