﻿/*
 * UPOU CMSC 204 - Data Structures and Algorithms
 * Student Name: Uttoh, Benjamin Ocampo
 * Student ID: 2018-30292
 * Created On: May 18, 2021
 * Brief Description of this Class: 
 * 
 * -- Stack class implementation using arrays.
 * -- Stack Class Variables: 
 *      Node[] stack - holds the Node array; represents the stack itself.
 *      int top - is the top pointer variable.
 *      int size - holds the current size of the stack.
 * -- Stack Class Methods:
 *      void Push(Node n) - pushes new node on top of the stack (or rightmost).
 *      Node Peek() - returns the top of the stack.
 *      void Pop() - removes the topmost item in the stack.
 *      bool isEmpty() - stack size checking.
 *      
*/

using System;

namespace WinFormsApp4
{
    class Stack
    {
        Node[] stack;
        int top = -1;
        int size = 0;

        // add new item to top of stack
        public void Push(Node n)
        {
            // grow the array size by 1
            Array.Resize(ref stack, ++size);

            // increment pointer and put data in
            // array with corresponding index
            stack[++top] = n;
        }

        // peek top item from stack
        public Node Peek()
        {
            if (!IsEmpty())
            {
                // if the stack has data,
                // return pointer's stack value
                return stack[top];
            }
            return null;
        }

        //  remove top item from stack
        public void Pop()
        {
            if (!IsEmpty())
            {
                // decrease size of array by 1
                Array.Resize(ref stack, --size);
                // decrease pointer index by 1
                top--;
            }
        }

        // empty checking
        public bool IsEmpty()
        {
            return size == 0;
        }
    }
}
